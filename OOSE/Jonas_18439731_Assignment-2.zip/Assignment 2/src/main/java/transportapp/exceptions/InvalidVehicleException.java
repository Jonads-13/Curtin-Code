package transportapp.exceptions;

public class InvalidVehicleException extends RuntimeException
{
    public InvalidVehicleException(String msg)
    {
        super(msg);
    }    
}
