package transportapp.exceptions;

public class InvalidPassengerException extends RuntimeException
{
    public InvalidPassengerException(String msg)
    {
        super(msg);
    }    
}
