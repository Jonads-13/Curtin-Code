package transportapp.vehicles;

/**
 * @Author    Jacob Jonas, 18439731
 * @Assertion Bus implementaion for the transport
 **/

public class Bus extends Vehicle
{
    public Bus(int id, String type, int fee)
    {
        super(id, type, fee);
    }
}
