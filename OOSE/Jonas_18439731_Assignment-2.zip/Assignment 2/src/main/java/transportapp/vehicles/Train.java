package transportapp.vehicles;

/**
 * @Author    Jacob Jonas, 18439731
 * @Assertion Train implementaion for the transport
 **/

public class Train extends Vehicle
{
    public Train(int id, String type, int fee)
    {
        super(id, type, fee);
    }
}
