package transportapp.vehicles;

/**
 * @Author    Jacob Jonas, 18439731
 * @Assertion Ferry implementaion for the transport
 **/

public class Ferry extends Vehicle
{
    public Ferry(int id, String type, int fee)
    {
        super(id,type,fee);
    }
}
