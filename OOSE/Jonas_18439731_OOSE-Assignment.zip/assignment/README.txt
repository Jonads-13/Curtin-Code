README
======

Jacob Jonas, 18439731
=====================


* Type "./gradlew run" to run. 
* Type "./gradlew check" to verify PMD rules. (On Windows, drop the "./" from start of course; i.e., "gradlew run" or "gradlew check".)
*
* "run" on its own will use the current directory as the root
* To specify a directory type "./gradlew run --args="some/directory""
