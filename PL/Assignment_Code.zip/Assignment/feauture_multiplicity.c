int main() {
    int index = 0;

    index = index + 1;
    index += 1;
    index++;
    ++index;
}