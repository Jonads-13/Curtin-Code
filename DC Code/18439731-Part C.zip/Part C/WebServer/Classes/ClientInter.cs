﻿namespace Classes
{
    public class ClientInter
    {
        public int Port { get; set; }
        public string Host { get; set; }
    }
}