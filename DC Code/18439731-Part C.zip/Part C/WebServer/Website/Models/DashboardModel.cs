﻿using Newtonsoft.Json;
using RestSharp;

namespace Website.Models
{
    public class DashboardModel
    {
        public List<Client> Clients { get; set; }
    }
}
