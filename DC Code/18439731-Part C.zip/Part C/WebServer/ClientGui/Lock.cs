﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientGui
{
    public static class Lock
    {
        public static bool Locked {  get; set; }
    }
}
