//
//  EmojiFlagsApp.swift
//  EmojiFlags
//
//  Created by Jake Jonas on 30/4/2024.
//

import SwiftUI

@main
struct EmojiFlagsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
