//
//  CaneToadAppApp.swift
//  CaneToadApp
//
//  Created by Jake Jonas on 23/4/2024.
//

import SwiftUI

@main
struct CaneToadAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
