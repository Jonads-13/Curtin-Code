//
//  IfStatementsApp.swift
//  IfStatements
//
//  Created by Jake Jonas on 12/3/2024.
//

import SwiftUI

@main
struct IfStatementsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
