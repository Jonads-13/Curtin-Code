//
//  ForInLoopApp.swift
//  ForInLoop
//
//  Created by Jake Jonas on 12/3/2024.
//

import SwiftUI

@main
struct ForInLoopApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
