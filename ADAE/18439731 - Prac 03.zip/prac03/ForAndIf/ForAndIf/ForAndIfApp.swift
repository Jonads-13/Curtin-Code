//
//  ForAndIfApp.swift
//  ForAndIf
//
//  Created by Jake Jonas on 13/3/2024.
//

import SwiftUI

@main
struct ForAndIfApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
