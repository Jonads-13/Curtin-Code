//
//  StructClassTestApp.swift
//  StructClassTest
//
//  Created by Jake Jonas on 19/3/2024.
//

import SwiftUI

@main
struct StructClassTestApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
