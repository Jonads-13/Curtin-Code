//
//  AppVIewsApp.swift
//  AppVIews
//
//  Created by Jake Jonas on 27/3/2024.
//

import SwiftUI

@main
struct AppVIewsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
