//
//  NewAlbum.swift
//  AppVIews
//
//  Created by Jake Jonas on 27/3/2024.
//

import SwiftUI
struct NewAlbum: View {
    var body: some View {
        VStack {
            Text("Scan New Album")
            Image("swift-og")
                .resizable()
        }
        .padding()
        
    }
}

#Preview {
    NewAlbum()
}
