//
//  ContentView.swift
//  AppVIews
//
//  Created by Jake Jonas on 27/3/2024.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationView() {
            VStack {
                NavigationLink(destination: NewAlbum()) {
                    Text("Add New Album")
                }
                NavigationLink(destination: CurrentAlbumsList()) {
                    Text("View Current Albums (List)")
                }
                NavigationLink(destination: CurrentAlbumsGrid()) {
                    Text("View Current Albums (Grid)")
                }
            }
        }
    }
}

#Preview {
    ContentView()
}
