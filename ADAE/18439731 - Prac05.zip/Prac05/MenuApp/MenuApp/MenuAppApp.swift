//
//  MenuAppApp.swift
//  MenuApp
//
//  Created by Jake Jonas on 31/3/2024.
//

import SwiftUI

@main
struct MenuAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
