//
//  CaneToadAppImprovedApp.swift
//  CaneToadAppImproved
//
//  Created by Jake Jonas on 24/4/2024.
//

import SwiftUI

@main
struct CaneToadAppImprovedApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
