#ifndef END_H
#define END_H

void playerTrapped(MapState*);
void goalBlocked(MapState*);
void endMessage(EndConditions*);
void freeStructs(MapState*);
void freeRecent(void*);

#endif
