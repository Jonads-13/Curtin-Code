#include <stdio.h>
#include <stdlib.h>
#include "linkedlist.h"

void insertFirst(List *list)
{
    ListNode *newNode = (ListNode*)malloc(sizeof(ListNode));
    newNode->next = NULL;

    if(list->head == NULL)
    {
        list->head = newNode;
    }
    else
    {
        newNode->next = list->head;
        list->head = newNode;
    }

    list->count++;
}

void* removeFirst(List* list)
{
    void *data;
    ListNode *curHead;
    
    if(list->head->next != NULL)
    { 
        data = list->head->data;

        curHead = list->head;
        list->head = list->head->next;

        data = curHead->data;

        free(curHead);
        curHead = NULL;
    }
    else
    {
        data = list->head->data;
        free(list->head);
        list->head = NULL;
    }

    list->count--;

    return data;
}

void freeLinkedList(List* list, FreePTR freeptr)
{
    ListNode *cur, *next;

    cur = list->head;

    while(cur != NULL)
    {
        next = cur->next;
        (freeptr)(cur->data);
        free(cur);

        cur = next;
   
        
    }

    free(list);
    list = NULL;
}
