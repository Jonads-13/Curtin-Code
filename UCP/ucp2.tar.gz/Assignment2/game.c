#include <stdio.h>
#include "linkedlist.h"
#include "structs.h"
#include "map.h"
#include "movement.h"
#include "end.h"
#include "game.h"
#include "macros.h"


/* 
 * Method:    game
 * Author:    Jacob Jonas, 18439731
 * Created:   22/08/2022
 * Modified:  06/10/2022
 * Import:    ms (MapState*)  
 * Export:    none 
 * Assertion: Everything related to the game during run-time 
 */

void game(MapState *ms)
{
    int count = ms->playerMovement->count;

    ms->end->won = FALSE, ms->end->playerTrapped = FALSE, ms->end->goalBlocked = FALSE;

    printMap(ms);  /*print the map initially before the player has done anything */

    /* Keep playing the game while all win and lose conditions are false */
    while((!ms->end->won) && (!ms->end->playerTrapped) && (!ms->end->goalBlocked))
    { 
        /* Ensures that floors aren't collapsing unless the player actually moves. */
        validMove(ms);

        if(count < ms->playerMovement->count)
        {
            floorCollapse(ms); /* Create a collapsed floor */

            /* Player and goal lost conditions are separate 
            * to display a more useful message to the player */
            playerTrapped(ms);
            goalBlocked(ms);
        }

        /* Print map at the end of the loop after everything has been done, ready for the next iteration */
        printMap(ms);

        count = ms->playerMovement->count;
    }  
    /* Once the game is completed, get a message describing the outcome */
    endMessage(ms->end);

    freeStructs(ms);
}



