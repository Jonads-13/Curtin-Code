#include <stdio.h>
#include <stdlib.h>
#include "linkedlist.h"
#include "structs.h"
#include "setup.h"
#include "map.h"
#include "game.h"
#include "macros.h"







/*
 * Title:     extract
 * Author:    Jacob Jonas, 18439731
 * Created:   06/09/2022
 * Modified:  08/10/2022
 * Import:    argv (char**)
 * Export:    none
 * Assertion: Extract the values from argv
 */

void extract(char** argv)
{
    FILE *fp = fopen(argv[1], "r");

    if(fp == NULL)
    {
        perror("Error opening file:");
    }
    else
    {
        setup(fp);
    }
}

/* 
 * Method:    setup
 * Author:    Jacob Jonas, 18439731
 * Created:   22/08/2022
 * Modified:  08/10/2022
 * Import:    fp (FILE*)
 * Export:    none
 * Assertion: Get everything ready to create the map for the game 
 */

void setup(FILE* fp)
{
    int nReads = 0, tempRow, tempCol;
    char tempChar;

    /* Allocate memory for main struct */
    MapState *ms = (MapState*)malloc(sizeof(MapState));

    /* Allocate memory for all sub structs */
    ms->mv = (MapValues*)malloc(sizeof(MapValues));
    ms->gv = (GoalValues*)malloc(sizeof(GoalValues));
    ms->end = (EndConditions*)malloc(sizeof(EndConditions));

    /* Allocate memory for linkedlist */
    ms->playerMovement = (List*)malloc(sizeof(List));
    ms->playerMovement->head = NULL;

    nReads = fscanf(fp, "%d %d", &tempRow, &tempCol);
    ms->mv->row = tempRow + 2;
    ms->mv->col = tempCol + 2;

    ms->map = createMap(ms->map, ms->mv->row, ms->mv->col);

    nReads = fscanf(fp, "%d %d %c", &tempRow, &tempCol, &tempChar);

    while(nReads == 3)
    {
        if(tempChar == 'P')
        {
            insertFirst(ms->playerMovement);
            ms->playerMovement->head->data = (Recent*)malloc(sizeof(Recent));

            ((struct Recent*)(ms->playerMovement->head->data))->playerRow = tempRow + 1;
            ((struct Recent*)(ms->playerMovement->head->data))->playerCol = tempCol + 1;

            ms->map[tempRow + 1][tempCol + 1] = 'P';
        }
        else if(tempChar == 'G')
        {
            ms->gv->row = tempRow + 1;
            ms->gv->col = tempCol + 1;
            ms->map[ms->gv->row][ms->gv->col] = 'G';
        }
        else
        {
            ms->map[tempRow + 1][tempCol + 1] = tempChar;
        }

        nReads = fscanf(fp, "%d %d %c", &tempRow, &tempCol, &tempChar);
    }

printf("Finshed setup\n");
    game(ms);
}





/* 
 * Method:    increaseValues
 * Author:    Jacob Jonas, 18439731
 * Created:   24/08/2022
 * Modified:  26/08/2022
 * Import:    arr (int*), n (int)
 * Export:    none 
 * Assertion: Get everything ready to create the map for the game 
 */

void increaseValues(int* arr, int n)
{
    int i;
    for(i = 0; i < 2; i++) /* each array will only ever be 2 elements long */
    {
        /* Because map values need to increased by 2,
         * and player and goal values only need to be increase by 1,
         * n is needed to change the increase value */
        arr[i] = arr[i] + n; 
    }
}
