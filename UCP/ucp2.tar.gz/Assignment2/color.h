#ifndef COLOR_H
#define COLOR_H

void setForeground(char * color);
void setBackground(char * color);

#endif
