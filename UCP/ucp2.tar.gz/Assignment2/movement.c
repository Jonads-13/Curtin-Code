/*
 * Title:     movement
 * Author:    Jacob Jonas, 18439731
 * Created:   22/08/2022
 * Modified:  06/09/2022
 * Assertion: All movement related functions for the game
 */

#include <stdio.h>
#include <stdlib.h>
#include "linkedlist.h"
#include "structs.h"
#include "movement.h"
#include "macros.h"
#include "terminal.h"




/*
 * Title:     validMove
 * Author:    Jacob Jonas, 18439731
 * Created:   06/09/2022
 * Modified:  06/09/2022
 * Import:    ms (MapState*)
 * Export:    won (int)
 * Assertion: Determine if a players move is valid
 */

void validMove(MapState *ms)
{
    int playerRowTemp, playerColTemp;
    char *direction = (char*)malloc(sizeof(char));
    DirectionPTR dPtr;

    /* Variables to check if the player has actually moved */
    playerRowTemp = ((struct Recent*)(ms->playerMovement->head->data))->playerRow;
    playerColTemp = ((struct Recent*)(ms->playerMovement->head->data))->playerCol;

    

    while((playerRowTemp == ((struct Recent*)(ms->playerMovement->head->data))->playerRow) && 
          (playerColTemp == ((struct Recent*)(ms->playerMovement->head->data))->playerCol))
    {
        disableBuffer(); /* Allow instantaneous input without "enter" key */
        scanf(" %c", direction); /* Get user's desired direction */
        enableBuffer(); /* Fix the terminal */

        /* get a pointer to a function that will perform the movement of the player */
        dPtr = movePlayer(direction);

        /* won condition is based on the return value of the movement functions */
        (dPtr)(ms);
    }

    free(direction);
    direction = NULL;
    
}






/* 
 * Method:    movePlayer
 * Author:    Jacob Jonas, 18439731
 * Created:   22/08/2022
 * Modified:  06/09/2022
 * Import:    direction (char*) 
 * Export:    ptr (FUNCPTR)   
 * Assertion: Return a function pointer that will carry out the chosen method direction
 */

DirectionPTR movePlayer(char *direction)
{
    /* Declare function pointer */
    DirectionPTR ptr;
    ptr = NULL;

    /* Depending on player input ,
     * Return a pointer to the corresponding function */
    switch(*direction)
    {
        case 'w': 
            ptr = &moveUp; 
        break;

        case 's':
            ptr = &moveDown;
        break;

        case 'a':
            ptr = &moveLeft;
        break;

        case 'd':
            ptr = &moveRight;
        break;

        case 'u':
            ptr = &undo;
        break;
    }

    return ptr; /* return function pointer */
}






/* 
 * Method:    moveUp
 * Author:    Jacob Jonas, 18439731
 * Created:   22/08/2022
 * Modified:  29/08/2022
 * Import:    ms->map (char**), mv (int*), pv (int*), gv (int*)
 * Export:    won (int)    
 * Assertion: Move the player up and return whether they won
 */

void moveUp(MapState* ms)
{
    int pr = ((struct Recent*)ms->playerMovement->head->data)->playerRow;
    int pc = ((struct Recent*)ms->playerMovement->head->data)->playerCol;

    if(ms->map[pr - 1][pc] == 'G') /* If player is moving onto the goal */ 
    {
        ms->map[pr - 1][pc] = 'P'; /* Place the player at the goal location */
        ms->map[pr][pc] = BLANK; /* Place a BLANK character where the player was */

        pr = pr - 1; /* Update the player's location */
        ms->end->won = TRUE; /* The player has now won the game */
    }
    
    #ifndef BORDERLESS /* When BORDERLESS is not defined */
        /* Don't allow the player to move if they are trying 
         * to move onto a 'X' or '*' character occupied space */
        else if((ms->map[pr - 1][pc] == 'X') || (ms->map[pr - 1][pc] == '*'))
        {}
    #endif

    #ifdef BORDERLESS /* When BORDERLESS is defined */
        /* Player can't move onto an 'X' character */
        else if(ms->map[pr - 1][pc] == 'X')
        {}
        /* The player cannot "warp" if the other side has an 'X' character */
        else if((ms->map[pr - 1][pc] == '*') && (ms->map[ms->mv->row - 2][pc] == 'X'))
        {}
        /* Player can "warp" if the other side does not have an 'X' character */
        else if((ms->map[pr - 1][pc] == '*') && (ms->map[ms->mv->row - 2][pc] != 'X'))
        {
            if(ms->map[ms->mv->row - 2][pc] == 'G') /* If the player is moving onto the goal */
            {
                ms->map[ms->mv->row - 2][pc] = 'P'; /* Place the player at the goal location */
                ms->map[pr][pc] = BLANK; /* Place a BLANK character where the player was */

                pr = ms->mv->row - 2; /* Update the player's location */
                ms->end->won = TRUE; /* The player has now won the game */
            }
            else
            {
                ms->map[ms->mv->row - 2][pc] = 'P'; /* Move the player to the free element */
                ms->map[pr][pc] = BLANK; /* Place a BLANK space where the player was */

                pr = ms->mv->row - 2; /* Update player location */
            }
        }
    #endif

    else
    { 
        ms->map[pr - 1][pc] = 'P'; /* Move the player to the free element */
        ms->map[pr][pc] = BLANK; /* Place a blank space where the player was */

        pr = pr - 1; /* Update player location */
    }

    if(pr != ((struct Recent*)ms->playerMovement->head->data)->playerRow)
    {
        insertFirst(ms->playerMovement);
        ms->playerMovement->head->data = (Recent*)malloc(sizeof(Recent));
        ((struct Recent*)ms->playerMovement->head->data)->playerRow = pr;
        ((struct Recent*)ms->playerMovement->head->data)->playerCol = pc;
    }
}





/* 
 * Method:    moveDown
 * Author:    Jacob Jonas, 18439731
 * Created:   22/08/2022
 * Modified:  29/08/2022
 * Import:    ms->map (char**), mv (int*), pv (int*), gv (int*)   
 * Export:    won (int)   
 * Assertion: Move the player down and return whether they won
 */

void moveDown(MapState* ms)
{
    int pr = ((struct Recent*)ms->playerMovement->head->data)->playerRow;
    int pc = ((struct Recent*)ms->playerMovement->head->data)->playerCol;
  
    if(ms->map[pr + 1][pc] == 'G') /* If player is moving onto the goal */
    {
        ms->map[pr + 1][pc] = 'P'; /* Place the player at the goal location */
        ms->map[pr][pc] = BLANK; /* Place a BLANK character where the player was */

        pr = pr + 1; /* Update the player's location */
        ms->end->won = TRUE; /* The player has now won the game */
    }

    #ifndef BORDERLESS /* When BORDERLESS is not defined */
        /* Don't allow the player to move if they are trying 
         * to move onto a 'X' or '*' character occupied space */
        else if((ms->map[pr + 1][pc] == 'X') || (ms->map[pr + 1][pc] == '*'))
        {}
    #endif

    #ifdef BORDERLESS /* When BORDERLESS is defined */
        /* Player can't move onto an 'X' character */
        else if(ms->map[pr + 1][pc] == 'X')
        {}
        /* The player cannot "warp" if the other side has an 'X' character */
        else if((ms->map[pr + 1][pc] == '*') && (ms->map[1][pc] == 'X'))
        {}
        /* Player can "warp" if the other side does not have an 'X' character */
        else if((ms->map[pr + 1][pc] == '*') && (ms->map[1][pc] != 'X'))
        {
            if(ms->map[1][pc] == 'G') /* If the player is moving onto the goal */
            {
                ms->map[1][pc] = 'P'; /* Place the player at the goal location */
                ms->map[pr][pc] = BLANK; /* Place a BLANK character where the player was */

                pr = 1; /* Update the player's location */
                ms->end->won = TRUE; /* Player has now won the game */
            }
            else
            {
                ms->map[1][pc] = 'P'; /* Move the player to the free element */
                ms->map[pr][pc] = BLANK; /* Place a BLANK space where the player was */

                pr = 1; /* Update player's location */
            }
        }
    #endif

    else
    {
        ms->map[pr + 1][pc] = 'P'; /* Move the player to the free element */
        ms->map[pr][pc] = BLANK; /* Place a BLANK space where the player was */

        pr = pr + 1; /* Update the player's location */
    }

    if(pr != ((struct Recent*)ms->playerMovement->head->data)->playerRow)
    {
        insertFirst(ms->playerMovement);
        ms->playerMovement->head->data = (Recent*)malloc(sizeof(Recent));
        ((struct Recent*)ms->playerMovement->head->data)->playerRow = pr;
        ((struct Recent*)ms->playerMovement->head->data)->playerCol = pc;
    }
}





/* 
 * Method:    moveLeft
 * Author:    Jacob Jonas, 18439731
 * Created:   22/08/2022
 * Modified:  29/08/2022
 * Import:    ms->map (char**), mv (int*), pv (int*), gv (int*)   
 * Export:    won (int)   
 * Assertion: Move the player left and return whether they won
 */

void moveLeft(MapState *ms)
{
    int pr = ((struct Recent*)ms->playerMovement->head->data)->playerRow;
    int pc = ((struct Recent*)ms->playerMovement->head->data)->playerCol;

    if(ms->map[pr][pc - 1] == 'G') /* If player is moving onto the goal */
    {
        ms->map[pr][pc - 1] = 'P'; /* Place the player at the goal location */
        ms->map[pr][pc] = BLANK; /* Place a BLANK character were the player was */

        pc = pc - 1; /* Update the player's location */
        ms->end->won = TRUE; /* Player has now won the game */
    }

    #ifndef BORDERLESS /* When BORDERLESS is not defined */
        /* Don't allow the player to move if they are trying 
         * to move onto a 'X' or '*' character occupied space */
        else if((ms->map[pr][pc - 1] == 'X') || (ms->map[pr][pc - 1] == '*'))
        {}
    #endif

    #ifdef BORDERLESS /* When BORDERLESS is defined */
        /* Player can't move onto an 'X' character */
        else if(ms->map[pr][pc - 1] == 'X')
        {}
        /* The player cannot "warp" if the other side has an 'X' character */
        else if((ms->map[pr][pc - 1] == '*') && (ms->map[pr][ms->mv->col - 2] == 'X'))
        {}
        /* Player can "warp" if the other side does not have an 'X' character */
        else if((ms->map[pr][pc - 1] == '*') && (ms->map[pr][ms->mv->col - 2] != 'X'))
        {
            if(ms->map[pr][ms->mv->col - 2] == 'G') /* If the player is moving onto the goal */
            {
                ms->map[pr][ms->mv->col - 2] = 'P'; /* Place the player at the goal location */
                ms->map[pr][pc] = BLANK; /* Place a BLANK character where the player was */

                pc = pc - 1; /* Update the player's location */
                ms->end->won = TRUE; /* Player has now won the game */
            }
            else
            {
                ms->map[pr][ms->mv->col - 2] = 'P'; /* Move the player to the free element */
                ms->map[pr][pc] = BLANK; /* Place a BLANK space where the player was */
                pc = ms->mv->col - 2; /* Update the player's location */
            }
        }
    #endif

    else
    {
        ms->map[pr][pc - 1] = 'P'; /* Move the player to the free element */
        ms->map[pr][pc] = BLANK; /* Place a BLANK space where the player was */

        pc = pc - 1; /* Update the player's location */
    }

    if(pc != ((struct Recent*)ms->playerMovement->head->data)->playerCol)
    {
        insertFirst(ms->playerMovement);
        ms->playerMovement->head->data = (Recent*)malloc(sizeof(Recent));
        ((struct Recent*)ms->playerMovement->head->data)->playerRow = pr;
        ((struct Recent*)ms->playerMovement->head->data)->playerCol = pc;
    }
}





/* 
 * Method:    moveRight
 * Author:    Jacob Jonas, 18439731
 * Created:   22/08/2022
 * Modified:  29/08/2022
 * Import:    ms->map (char**), mv (int*), pv (int*), gv (int*)    
 * Export:    won (int)  
 * Assertion: Move the player right and return whether they won
 */

void moveRight(MapState *ms)
{
    int pr = ((struct Recent*)ms->playerMovement->head->data)->playerRow;
    int pc = ((struct Recent*)ms->playerMovement->head->data)->playerCol;

    if(ms->map[pr][pc + 1] == 'G') /* If the player is moving onto the goal */
    {
        ms->map[pr][pc + 1] = 'P'; /* Place the player at the goal location */
        ms->map[pr][pc] = BLANK; /* Place a BLANK character where tthe player was */

        pc = pc + 1; /* Update player's location */
        ms->end->won = TRUE; /* Player has now won the game */
    }

    #ifndef BORDERLESS /* When BORDERLESS is not defined */
        /* Don't allow the player to move if they are trying 
         * to move onto a 'X' or '*' character occupied space */
        else if((ms->map[pr][pc + 1] == 'X') || (ms->map[pr][pc + 1] == '*'))
        {}
    #endif

    #ifdef BORDERLESS /* When BORDERLESS is defined */
        /* Player can't move onto an 'X' character */
        else if(ms->map[pr][pc + 1] == 'X')
        {}
        /* The player cannot "warp" if the other side has an 'X' character */
        else if((ms->map[pr][pc + 1] == '*') && (ms->map[pr][1] == 'X'))
        {}
        /* Player can "warp" if the other side does not have an 'X' character */
        else if((ms->map[pr][pc + 1] == '*') && (ms->map[pr][1] != 'X'))
        {
            if(ms->map[pr][1] == 'G') /* If the player is moving onto the goal */
            {
                ms->map[pr][1] = 'P'; /* Place the player at the goal location */
                ms->map[pr][pc] = BLANK; /* Place a BLANK character where the player was */

                pc = pc + 1; /* Update player's location */
                ms->end->won = TRUE; /* PLayer has now won the game */
            }
            else
            {
                ms->map[pr][1] = 'P'; /* Move the player to the free element */
                ms->map[pr][pc] = BLANK; /* Place a BLANK character where the player was */
                pc = 1; /* Update plaer's location */
            }
        }
    #endif

    else
    {
        ms->map[pr][pc + 1] = 'P'; /* Move the player to the free element */
        ms->map[pr][pc] = BLANK; /* Place a BLANK character where the player was */

        pc = pc + 1; /* Update player's location */
    }

    if(pc != ((struct Recent*)ms->playerMovement->head->data)->playerCol)
    {
        insertFirst(ms->playerMovement);
        ms->playerMovement->head->data = (Recent*)malloc(sizeof(Recent));
        ((struct Recent*)ms->playerMovement->head->data)->playerRow = pr;
        ((struct Recent*)ms->playerMovement->head->data)->playerCol = pc;
    } 
}






/*
 * Title:     undo
 * Author:    Jacob Jonas, 18439731
 * Created:   08/10/2022
 * Modified:  08/10/2022
 * Import:    ms (ms->mapState*)
 * Export:    won (int)
 * Assertion: Undo the last move done by the player
 */

void undo(MapState *ms)
{
    int row = 1, col = 1;
    struct Recent* latest;

    if(ms->playerMovement->head->next != NULL)
    {
        latest = (Recent*)removeFirst(ms->playerMovement);

        ms->map[latest->floorRow][latest->floorCol] = BLANK;
        ms->map[latest->playerRow][latest->playerCol] = BLANK;

        row = ((struct Recent*)ms->playerMovement->head->data)->playerRow;
        col = ((struct Recent*)ms->playerMovement->head->data)->playerCol;

        ms->map[row][col] = 'P';

        free(latest);
        latest = NULL;
    }
}


