#ifndef SETUP_H
#define SETUP_H

void extract(char**);
void setup(FILE*);

#endif
