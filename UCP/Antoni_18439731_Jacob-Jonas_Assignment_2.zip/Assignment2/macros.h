#ifndef MACROS_H
#define MACROS_H

#define FALSE 0
#define TRUE !FALSE

#define BLANK ' '

typedef void (*DirectionPTR)(MapState*);

#endif
