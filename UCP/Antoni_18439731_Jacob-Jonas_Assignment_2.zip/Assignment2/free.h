#ifndef FREE_H
#define FREE_H

void freeStructs(MapState*);
void freeMap(char**, int);
void freeRecent(void*);

#endif
