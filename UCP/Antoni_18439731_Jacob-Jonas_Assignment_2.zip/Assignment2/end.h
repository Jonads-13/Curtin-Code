#ifndef END_H
#define END_H

void playerTrapped(MapState*);
void goalBlocked(MapState*);

#endif
