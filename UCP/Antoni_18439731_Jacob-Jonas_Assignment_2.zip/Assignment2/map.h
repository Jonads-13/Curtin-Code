#ifndef MAP_H
#define MAP_H

char** createMap(char**, int, int);
void printMap(MapState*);
void floorCollapse(MapState*);

#endif
