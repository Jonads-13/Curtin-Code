#ifndef RANDOM_H
#define RANDOM_H

void initRandom();
int randomNum(int low, int high);

#endif
