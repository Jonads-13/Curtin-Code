#ifndef MAP_H
#define MAP_H

#include "structs.h"

char** createDisplay(char**, int, int);
int** createColorState(int**, int, int);
void printMap(State*);

#endif
