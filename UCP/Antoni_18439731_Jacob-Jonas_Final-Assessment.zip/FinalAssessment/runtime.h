#ifndef RUNTIME_H
#define RUNTIME_H

#include "structs.h"

void begin(State*);
void changeLangColor(Ant*, int**);
void changeRandColor(Ant*, int**);

#endif
